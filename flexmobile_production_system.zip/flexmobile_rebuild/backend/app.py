import os
from datetime import datetime, timedelta, date
from decimal import Decimal
from typing import Optional
import jwt
from passlib.context import CryptContext
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, Numeric, Date, DateTime, ForeignKey, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./flexmobile.db')
JWT_SECRET = os.getenv('JWT_SECRET')
if not JWT_SECRET:
    # Development-only fallback. Set a long random secret before any deployment.
    JWT_SECRET = 'DEV-ONLY-CHANGE-THIS-SECRET'
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
pwd = CryptContext(schemes=['bcrypt'], deprecated='auto')

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(primary_key=True)
    email: Mapped[str]=mapped_column(String(200), unique=True, index=True)
    password_hash: Mapped[str]=mapped_column(String(300))
    role: Mapped[str]=mapped_column(String(30), default='admin')
class Customer(Base):
    __tablename__='customers'
    id: Mapped[int]=mapped_column(primary_key=True)
    full_name: Mapped[str]=mapped_column(String(200))
    national_id: Mapped[str]=mapped_column(String(100), index=True)
    phone: Mapped[str]=mapped_column(String(40))
    monthly_income: Mapped[Decimal]=mapped_column(Numeric(12,2), default=0)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
class Device(Base):
    __tablename__='devices'
    id: Mapped[int]=mapped_column(primary_key=True)
    brand: Mapped[str]=mapped_column(String(80))
    model: Mapped[str]=mapped_column(String(120))
    imei: Mapped[Optional[str]]=mapped_column(String(80), nullable=True, unique=True)
    cash_price: Mapped[Decimal]=mapped_column(Numeric(12,2))
    status: Mapped[str]=mapped_column(String(30), default='available')
class Contract(Base):
    __tablename__='contracts'
    id: Mapped[int]=mapped_column(primary_key=True)
    customer_id: Mapped[int]=mapped_column(ForeignKey('customers.id'))
    device_id: Mapped[int]=mapped_column(ForeignKey('devices.id'))
    cash_price: Mapped[Decimal]=mapped_column(Numeric(12,2))
    margin_percent: Mapped[Decimal]=mapped_column(Numeric(6,2), default=30)
    total_due: Mapped[Decimal]=mapped_column(Numeric(12,2))
    term_months: Mapped[int]=mapped_column(Integer, default=4)
    start_date: Mapped[date]=mapped_column(Date)
    status: Mapped[str]=mapped_column(String(30), default='active')
class Installment(Base):
    __tablename__='installments'
    id: Mapped[int]=mapped_column(primary_key=True)
    contract_id: Mapped[int]=mapped_column(ForeignKey('contracts.id'))
    due_date: Mapped[date]=mapped_column(Date)
    amount_due: Mapped[Decimal]=mapped_column(Numeric(12,2))
    amount_paid: Mapped[Decimal]=mapped_column(Numeric(12,2), default=0)
    status: Mapped[str]=mapped_column(String(30), default='pending')
class Payment(Base):
    __tablename__='payments'
    id: Mapped[int]=mapped_column(primary_key=True)
    contract_id: Mapped[int]=mapped_column(ForeignKey('contracts.id'))
    amount: Mapped[Decimal]=mapped_column(Numeric(12,2))
    reference: Mapped[str]=mapped_column(String(120), unique=True)
    paid_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[Optional[int]]=mapped_column(Integer, nullable=True)
    action: Mapped[str]=mapped_column(String(120))
    details: Mapped[str]=mapped_column(String(1000), default='')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
Base.metadata.create_all(engine)
app=FastAPI(title='FlexMobile Financing API', version='0.2.0')
origins=os.getenv('CORS_ORIGINS','http://localhost:5173').split(',')
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in origins], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
class LoginInput(BaseModel): email: str; password: str
class CustomerInput(BaseModel): full_name: str; national_id: str; phone: str; monthly_income: Decimal=0
class DeviceInput(BaseModel): brand: str; model: str; imei: Optional[str]=None; cash_price: Decimal=Field(gt=0)
class ContractInput(BaseModel): customer_id: int; device_id: int; start_date: date; term_months: int=Field(default=4, ge=1, le=24); margin_percent: Decimal=Field(default=30, ge=0, le=200)
class PaymentInput(BaseModel): contract_id: int; amount: Decimal=Field(gt=0); reference: str=Field(min_length=3, max_length=120)
def current_user(authorization: str=Header(default=''), s: Session=Depends(db)):
    if not authorization.startswith('Bearer '): raise HTTPException(401,'Missing bearer token')
    try: payload=jwt.decode(authorization[7:], JWT_SECRET, algorithms=['HS256']); uid=int(payload['sub'])
    except Exception: raise HTTPException(401,'Invalid token')
    user=s.get(User,uid)
    if not user: raise HTTPException(401,'User not found')
    return user
@app.get('/health')
def health(): return {'status':'ok','service':'FlexMobile API'}
@app.post('/setup/admin')
def setup_admin(data: LoginInput, s: Session=Depends(db)):
    # One-time bootstrap only. Protect this endpoint with SETUP_TOKEN and remove/disable after setup.
    token=os.getenv('SETUP_TOKEN')
    if not token: raise HTTPException(403,'Admin bootstrap disabled; set SETUP_TOKEN temporarily')
    # Setup token must be sent as X-Setup-Token; handled by separate header below in deployment version.
    if s.scalar(select(User.id).limit(1)): raise HTTPException(409,'A user already exists')
    user=User(email=data.email.lower(),password_hash=pwd.hash(data.password),role='admin'); s.add(user); s.commit()
    return {'created':True,'message':'Admin created. Disable SETUP_TOKEN now.'}
@app.post('/auth/login')
def login(data: LoginInput, s: Session=Depends(db)):
    user=s.scalar(select(User).where(User.email==data.email.lower()))
    if not user or not pwd.verify(data.password,user.password_hash): raise HTTPException(401,'Invalid email or password')
    token=jwt.encode({'sub':str(user.id),'exp':datetime.utcnow()+timedelta(hours=8)},JWT_SECRET,algorithm='HS256')
    return {'access_token':token,'token_type':'bearer','role':user.role}
@app.get('/customers')
def customers(s: Session=Depends(db), u=Depends(current_user)):
    return [{'id':x.id,'full_name':x.full_name,'national_id':x.national_id,'phone':x.phone,'monthly_income':str(x.monthly_income)} for x in s.scalars(select(Customer).order_by(Customer.id.desc())).all()]
@app.post('/customers')
def create_customer(data: CustomerInput, s: Session=Depends(db), u=Depends(current_user)):
    if s.scalar(select(Customer).where(Customer.national_id==data.national_id)): raise HTTPException(409,'Customer ID already exists')
    x=Customer(**data.model_dump()); s.add(x); s.flush(); s.add(AuditLog(user_id=u.id,action='customer.created',details=f'customer_id={x.id}')); s.commit(); return {'id':x.id}
@app.get('/devices')
def devices(s: Session=Depends(db), u=Depends(current_user)):
    return [{'id':x.id,'brand':x.brand,'model':x.model,'imei':x.imei,'cash_price':str(x.cash_price),'status':x.status} for x in s.scalars(select(Device).order_by(Device.id.desc())).all()]
@app.post('/devices')
def create_device(data: DeviceInput, s: Session=Depends(db), u=Depends(current_user)):
    if data.imei and s.scalar(select(Device).where(Device.imei==data.imei)): raise HTTPException(409,'IMEI already registered')
    x=Device(**data.model_dump()); s.add(x); s.flush(); s.add(AuditLog(user_id=u.id,action='device.created',details=f'device_id={x.id}')); s.commit(); return {'id':x.id}
@app.post('/contracts')
def create_contract(data: ContractInput, s: Session=Depends(db), u=Depends(current_user)):
    customer=s.get(Customer,data.customer_id); device=s.get(Device,data.device_id)
    if not customer: raise HTTPException(404,'Customer not found')
    if not device or device.status!='available': raise HTTPException(409,'Device unavailable')
    price=Decimal(device.cash_price); total=(price*(Decimal(1)+data.margin_percent/Decimal(100))).quantize(Decimal('0.01'))
    c=Contract(customer_id=customer.id,device_id=device.id,cash_price=price,margin_percent=data.margin_percent,total_due=total,term_months=data.term_months,start_date=data.start_date)
    s.add(c); s.flush(); base=(total/Decimal(data.term_months)).quantize(Decimal('0.01'))
    allocated=Decimal('0')
    for i in range(data.term_months):
        amount=total-allocated if i==data.term_months-1 else base; allocated+=amount
        # Due monthly on the same day where possible; cap day at 28 for predictable dates.
        month_index=data.start_date.month-1+i; year=data.start_date.year+month_index//12; month=month_index%12+1
        due=date(year,month,min(data.start_date.day,28))
        s.add(Installment(contract_id=c.id,due_date=due,amount_due=amount,amount_paid=0,status='pending'))
    device.status='financed'; s.add(AuditLog(user_id=u.id,action='contract.created',details=f'contract_id={c.id}; total={total}')); s.commit()
    return {'id':c.id,'total_due':str(total),'term_months':c.term_months,'installment_amount_approx':str(base)}
@app.get('/contracts')
def contracts(s: Session=Depends(db), u=Depends(current_user)):
    return [{'id':c.id,'customer_id':c.customer_id,'device_id':c.device_id,'total_due':str(c.total_due),'term_months':c.term_months,'start_date':str(c.start_date),'status':c.status} for c in s.scalars(select(Contract).order_by(Contract.id.desc())).all()]
@app.post('/payments')
def record_payment(data: PaymentInput, s: Session=Depends(db), u=Depends(current_user)):
    if s.scalar(select(Payment).where(Payment.reference==data.reference)): raise HTTPException(409,'Payment reference already used')
    c=s.get(Contract,data.contract_id)
    if not c: raise HTTPException(404,'Contract not found')
    installments=s.scalars(select(Installment).where(Installment.contract_id==c.id).order_by(Installment.due_date,Installment.id)).all()
    remaining=data.amount
    outstanding=sum((Decimal(x.amount_due)-Decimal(x.amount_paid) for x in installments),Decimal('0'))
    if data.amount>outstanding: raise HTTPException(422,f'Payment exceeds outstanding balance ({outstanding})')
    p=Payment(contract_id=c.id,amount=data.amount,reference=data.reference); s.add(p)
    for inst in installments:
        due=Decimal(inst.amount_due)-Decimal(inst.amount_paid)
        if remaining<=0: break
        applied=min(due,remaining); inst.amount_paid=Decimal(inst.amount_paid)+applied; remaining-=applied
        inst.status='paid' if inst.amount_paid>=inst.amount_due else ('partial' if inst.amount_paid>0 else 'pending')
    for inst in installments:
        if inst.status!='paid' and inst.due_date<date.today(): inst.status='overdue'
    if all(x.status=='paid' for x in installments): c.status='completed'
    s.add(AuditLog(user_id=u.id,action='payment.recorded',details=f'contract_id={c.id}; amount={data.amount}; reference={data.reference}')); s.commit()
    return {'payment_id':p.id,'amount_recorded':str(data.amount),'outstanding_balance':str(outstanding-data.amount)}
@app.get('/dashboard')
def dashboard(s: Session=Depends(db), u=Depends(current_user)):
    contracts=s.scalars(select(Contract)).all(); customers=s.scalars(select(Customer)).all(); devices=s.scalars(select(Device)).all(); payments=s.scalars(select(Payment)).all(); installments=s.scalars(select(Installment)).all()
    overdue=sum((Decimal(x.amount_due)-Decimal(x.amount_paid) for x in installments if x.due_date<date.today() and x.status!='paid'),Decimal('0'))
    return {'customers':len(customers),'devices_total':len(devices),'devices_available':sum(1 for x in devices if x.status=='available'),'contracts_active':sum(1 for x in contracts if x.status=='active'),'payments_count':len(payments),'overdue_balance':str(overdue)}
