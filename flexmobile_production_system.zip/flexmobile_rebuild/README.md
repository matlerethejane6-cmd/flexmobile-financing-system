# FlexMobile Financing System — starter package

This is a development starter, not a production-certified financial system. It includes a FastAPI API, PostgreSQL via Docker Compose, a small React dashboard, customer/device/contract/installment/payment records, and basic audit logging.

## Run locally
1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and set strong unique values for `POSTGRES_PASSWORD`, `JWT_SECRET`, and `SETUP_TOKEN`.
3. Run `docker compose up --build`.
4. API health: http://localhost:8000/health ; API docs: http://localhost:8000/docs ; dashboard: http://localhost:5173.
5. Create the first admin using `POST /setup/admin` with JSON `{ "email": "your-email@example.com", "password": "a-long-unique-password" }`. IMPORTANT: this simplified bootstrap endpoint currently needs to be protected with a setup-token header before use. Do not expose it publicly as-is; create the admin locally or add and test that header protection before deployment.
6. Sign in at the dashboard.

## Deployment notes
- Frontend requires `VITE_API_URL` set to the deployed API origin at build time.
- Set `DATABASE_URL`, `JWT_SECRET`, `CORS_ORIGINS`, and a temporary `SETUP_TOKEN` securely in the hosting provider dashboard.
- Do not use default or development secrets in production.
- Use managed PostgreSQL backups, TLS, migrations, access controls, monitoring, and a tested recovery procedure before storing customer data.

## Important limitations
- This is a starter for development/testing, not a finished regulated-finance application.
- The admin bootstrap endpoint needs proper setup-token header enforcement and should be disabled after the first admin is created.
- No document/Google Drive integration, automated reminders, approval workflow, full user administration, formal migrations, or device-lock integration is implemented.
- Payment allocation and monthly schedules need comprehensive automated tests and accounting review before real transactions.
- Device restriction must use approved Android Enterprise/Android Management enrollment and transparent contractual consent; ordinary apps cannot guarantee reset resistance.
- Confirm Lesotho legal, privacy, consumer-credit, and financial-services obligations with qualified professionals before launch.
